import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewUserTableComponent } from './view-user-table.component';

describe('ViewUserTableComponent', () => {
  let component: ViewUserTableComponent;
  let fixture: ComponentFixture<ViewUserTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewUserTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewUserTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
