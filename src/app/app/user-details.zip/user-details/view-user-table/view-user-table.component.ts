import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/shared/login.service';
import { UserDetails } from 'src/app/shared/user-details.model';
import { UserDetailsService } from 'src/app/shared/user-details.service';

@Component({
  selector: 'app-view-user-table',
  templateUrl: './view-user-table.component.html',
  styleUrls: ['./view-user-table.component.css']
})
export class ViewUserTableComponent implements OnInit {

  constructor(public service: UserDetailsService, public admin: LoginService,
    public router: Router) { }

  ngOnInit(): void {
    console.log("called");
    if(this.admin.getUsername() == 101010 )
    {
      this.service.refreshList();
    }
    else{
      this.router.navigate([`denied`]);
    }
    //this.service.refreshList();
  }

  populateForm(selectedRecord: UserDetails)
  {
    this.service.formData = Object.assign({}, selectedRecord);
  }

  onDelete(id: number)
  {
    if(confirm("Are you sure to delete this record?"))
    {
      this.service.deleteUserDetails(id).subscribe(
        res=>{
          this.service.refreshList();
          console.log("delted sucessfully")
        },
        err=>{
          console.log(err);
        }
      )
    }
    
  }

  viewUsers(){
    this.router.navigate([`users`]);
  }

  public logout(): void{
    this.admin.logout();
    this.router.navigate(['']);
  }

}
